import { useState } from 'react'
import './App.css'
import UseStateExample from './Hooks/UseStateExample'
import "./output.css"
import InputExample from './Hooks/InputExample'
import ToggleExample from './Hooks/ToggleExample'
import ArrayExample from './Hooks/ArrayExample'
import ProfileDetails from './Hooks/ProfileDetails'
import CharaterCounter from './Hooks/CharaterCounter'
import DarkModeToggle from './Hooks/DarkModeToggle'
import PasswordHideShow from './Hooks/PasswordHideShow'
import LikeButtonCounter from './Hooks/LikeButtonCounter'

function App() {

  return (
    <>
      <UseStateExample />
      <InputExample />
      <ToggleExample />
      <ArrayExample />
      <ProfileDetails />
      <CharaterCounter />
      <DarkModeToggle />
      <PasswordHideShow />
      <LikeButtonCounter />
    </>
  )
}

export default App
