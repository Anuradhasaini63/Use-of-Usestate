import React, { useState } from 'react'

const ToggleExample = () => {
    const [isVisible, setIsvisisble]  = useState(true)
  return (
    <>
<div className='bg-blue-300 p-10 mt-5'>
        <div className="text-black font-semibold">Toggle Example</div>
            <div className='flex gap-2 justify-center mt-5 align-center'>
              <button className='bg-blue-800 py-1 px-2 text-white' onClick={()=>setIsvisisble(!isVisible)}>
                {isVisible ? "Hide" : "Show"} Text 
                </button>
                {isVisible && <p className='text-blue-800'>Text is visible</p> }
                </div>
                </div>
                </>
  )
}

export default ToggleExample