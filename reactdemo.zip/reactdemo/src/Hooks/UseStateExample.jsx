import React, { useState } from 'react'

const UseStateExample = () => {
 const [count, setCount] = useState(0)

 function increment()
 {
    setCount(count+1)
 }
 function decrement()
 {
    setCount(count-1)
 }

  return (
<>
<div className='bg-blue-300 p-10'>
        <div className="text-black font-semibold">Counter Example</div>
            <div className='flex gap-2 justify-center mt-5 align-center'>
                <button className="bg-blue-800 px-2 text-white" onClick={increment}>+</button>
                <input className='border px-2 py-1' value={count} type="text" readOnly />
                <button className="bg-blue-800 px-2 text-white" onClick={decrement}>-</button>    
            </div>
            </div>
    </>
  )
}

export default UseStateExample