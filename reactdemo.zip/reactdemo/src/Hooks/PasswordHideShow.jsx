import React, { useState } from 'react';
// import { Eye, EyeOff } from "lucide-react";

const PasswordHideShow = () => {
    const [showPassword, setShowPassword] = useState(false);
  return (
    <>
    <div className='bg-blue-300 p-10 mt-5'>
            <div className="text-black font-semibold">Password hide and show</div>
            <div className='mt-5'>
   <div> 
    <input type={showPassword ? "text" : "password"} className='border px-2 py-1' /></div>
<button onClick={()=> setShowPassword(!showPassword)}>Show</button>
    </div>
                    </div>
                    </>
  )
}

export default PasswordHideShow