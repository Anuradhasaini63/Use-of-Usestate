import React, { useState } from 'react'

const LikeButtonCounter = () => {
  const [likeCount, setLikeCount] = useState(0)
  function Addlike()
  {
    setLikeCount(likeCount + 1);
  }
  return (
    <>
    <div className='bg-blue-300 p-10 mt-5'>
    <div className="text-black font-semibold">Like Button Counter</div>
    <div className='mt-5'>
        <button className='bg-blue-800 text-white px-2' onClick={Addlike}>Like</button>
     <p>{likeCount}</p>
    </div>
    </div>
    </>
  )
}

export default LikeButtonCounter