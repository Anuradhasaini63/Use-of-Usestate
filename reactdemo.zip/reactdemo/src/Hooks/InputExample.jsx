import React, { useState } from 'react'

const InputExample = () => {
    const [text, setText] = useState()
  return (
    <>
    <div className='bg-blue-300 p-10 mt-5'>
    <div className="text-black font-semibold">Input Example</div>
    <div className='mt-5'>
   <div> <input type="text" className='border px-2 py-1' value={text} onChange={(e) =>setText(e.target.value)} /></div>
    <p className='font-semibold mt-5'>Text Display: {text}</p>
    </div>
    </div>
    </>
  )
}

export default InputExample