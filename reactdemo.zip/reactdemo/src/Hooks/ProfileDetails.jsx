import React, { useState } from 'react'

const ProfileDetails = () => {
    const [user, setUser] = useState({name: "", age: ""})
  return (
    <>
     <div className='bg-blue-300 p-10 mt-5'>
        <h2>Profile Details</h2>
        <div className='flex gap-2 justify-center mt-5'>
            <input className='border px-2 py-1' type="text" value={user.name} onChange={(e) =>setUser({...user, name:e.target.value})} />
            <input className='border px-2 py-1' type="text" value={user.age} onChange={(e)=> setUser({...user, age:e.target.value})} />
        </div> 
        <p className='font-semibold'>Name: {user.name}, Age: {user.age}</p>
    </div>
    </>
  )
}

export default ProfileDetails