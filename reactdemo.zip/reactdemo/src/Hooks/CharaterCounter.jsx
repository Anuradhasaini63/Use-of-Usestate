import React, { useState } from 'react'

const CharaterCounter = () => {
  const [text, setText] = useState(" ")
  return (
    <>
    <div className='bg-blue-300 p-10 mt-5'>
    <div className="text-black font-semibold">Charater Counter</div>
    <div className='mt-5'>
      <input type="text" className='border px-2 py-1' value={text} onChange={(e)=> setText(e.target.value)}/>
      <p>{text.length}</p>
    </div>
    </div>
    </>
  )
}

export default CharaterCounter