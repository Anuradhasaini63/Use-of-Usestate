import React, { useState } from 'react';

const DarkModeToggle = () => {
    const [darkmode, setDarkMode] = useState(false);
    const toggleDarkMode = () => {
        setDarkMode(!darkmode)
    };
  return (
   <>
    <div className='bg-blue-300 p-10 mt-5'>
    <div className="text-black font-semibold">Mode of theme is : {darkmode ? "Light Mode" : "Dark Mode"}</div>
    <div className='flex gap-2 justify-center mt-5 align-center'>
    <div className={`p-2 w-1/4 ${darkmode ? "text-black bg-white" : "text-white bg-blue-800"}`}>Mode of Theme</div>
    </div>
    <button className='mt-2' onClick={toggleDarkMode}>
        {darkmode ? "Dark Mode" : "Light Mode"}
    </button>
    </div>
    </>

  )
}

export default DarkModeToggle;