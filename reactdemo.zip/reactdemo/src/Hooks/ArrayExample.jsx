import React, { useState } from 'react'

const ArrayExample = () => {
    const [items, setitem] = useState([])
    function addItem()
    {
        setitem([...items, ` ${items.length * 5}`])
    }
  return (
    <>
    <div className='bg-blue-300 p-10 mt-5'>
            <div className="text-black font-semibold">Array Example</div>
                <div className='mt-5'>
                    <button className='bg-blue-800 px-2 text-white' onClick={addItem}>Add Item</button>
                    <ul className='flex gap-2 justify-center mt-5'> 
                        <b>Array: </b>
                        {items.map((item, index) =>(
                            <li key={index}>{item}, </li>
                        ))}
                    </ul>
                    </div>
                    </div>
                    </>
  )
}

export default ArrayExample